import iterators.Iterator;

public class TestIterators {
	public static void main(String[] args) {
		Iterator it = new Iterator();
		System.out.println("Done");	
	}
}
