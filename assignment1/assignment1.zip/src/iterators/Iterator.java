package iterator;

public class Iterator {
	public Iterator() {
		System.out.println("Making iterator");
	}
}
